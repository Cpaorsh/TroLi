CREATE DATABASE  IF NOT EXISTS `newspage` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `newspage`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: newspage
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sinhvien`
--

DROP TABLE IF EXISTS `sinhvien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sinhvien` (
  `msv` varchar(45) NOT NULL,
  `hoten` varchar(45) NOT NULL,
  `ngaysinh` varchar(45) NOT NULL,
  `lop` varchar(45) NOT NULL,
  `chucvu` varchar(45) NOT NULL DEFAULT 'sv',
  PRIMARY KEY (`msv`),
  UNIQUE KEY `msv_UNIQUE` (`msv`),
  CONSTRAINT `usersv` FOREIGN KEY (`msv`) REFERENCES `users` (`max`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sinhvien`
--

LOCK TABLES `sinhvien` WRITE;
/*!40000 ALTER TABLE `sinhvien` DISABLE KEYS */;
INSERT INTO `sinhvien` VALUES ('640001','Quan Văn Chuẩn','08/07/01','K64HTTT','loptruong'),('640002','Phạm Xuân Mạnh','06/08/01','K64HTTT','sv'),('640003','Vũ Đình Hai','03/08/01','K64HTTT','sv'),('640004','Nguyễn Thái Sơn','20/01/01','K64HTTT','sv'),('640005','Đậu Văn Toàn','13/10/01','K64CNPM','loptruong'),('640006','Nguyễn Hai Long','15/05/01','K64CNPM','sv'),('640007','Nguyễn Đình Bắc','15/06/01','K64CNTT','sv'),('640008','Nguyễn Văn Trường','15/07/01','K64CNTT','sv'),('640009','Phạm Tuấn Hải','15/08/01','K64CNTT','sv'),('640010','Nguyễn Văn Quyết','15/09/01','K64HTTT','sv'),('640011','Đỗ Duy Mạnh','03/08/05','K64CNTT','sv'),('640012','Nguyễn Thành Chung','06/08/05','K64CNTT','sv'),('640013','Đào Văn Nam','08/07/05','K64CNTT','loptruong'),('640014','Đỗ Duy Mạnh','12/12/05','K64HTTT','sv'),('640015','Lê Văn Xuân','05/08/05','K64HTTT','sv'),('640016','Trương Văn Thái Quý','18/10/05','K64HTTT','sv'),('640017','Đỗ Hùng Dũng','15/03/05','K64HTTT','sv'),('640018','Phạm Thành Lương','07/02/05','K64HTTT','sv'),('640019','Nguyễn Văn Tùng','23/07/05','K64CNPM','sv');
/*!40000 ALTER TABLE `sinhvien` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-10 21:16:37
