CREATE DATABASE  IF NOT EXISTS `newspage` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `newspage`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: newspage
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drl`
--

DROP TABLE IF EXISTS `drl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drl` (
  `msv` varchar(45) NOT NULL,
  `ythuc` int DEFAULT '0',
  `clbhoc` int DEFAULT '0',
  `quyche` int DEFAULT '0',
  `vuotkho` int DEFAULT '0',
  `hoctap` int DEFAULT '0',
  `tsvgioi` int DEFAULT '0',
  `kqchaphanh` int DEFAULT '0',
  `tgngoaikhoa` int DEFAULT '0',
  `dangnn` int DEFAULT '0',
  `bieuduong` int DEFAULT '0',
  `giupdo` int DEFAULT '0',
  `tgdoanhoi` int DEFAULT '0',
  `tongdiem` int GENERATED ALWAYS AS ((((((((((((`ythuc` + `clbhoc`) + `quyche`) + `vuotkho`) + `hoctap`) + `tsvgioi`) + `kqchaphanh`) + `tgngoaikhoa`) + `dangnn`) + `bieuduong`) + `giupdo`) + `tgdoanhoi`)) VIRTUAL,
  `ltythuc` int DEFAULT (`ythuc`),
  `ltclbhoc` int DEFAULT (`clbhoc`),
  `ltquyche` int DEFAULT (`quyche`),
  `ltvuotkho` int DEFAULT (`vuotkho`),
  `lthoctap` int DEFAULT (`hoctap`),
  `lttsvgioi` int DEFAULT (`tsvgioi`),
  `ltkqchaphanh` int DEFAULT (`kqchaphanh`),
  `lttgngoaikhoa` int DEFAULT (`tgngoaikhoa`),
  `ltdangnn` int DEFAULT (`dangnn`),
  `ltbieuduong` int DEFAULT (`bieuduong`),
  `ltgiupdo` int DEFAULT (`giupdo`),
  `lttgdoanhoi` int DEFAULT (`tgdoanhoi`),
  `lttongdiem` int GENERATED ALWAYS AS ((((((((((((`ltythuc` + `ltclbhoc`) + `ltquyche`) + `ltvuotkho`) + `lthoctap`) + `lttsvgioi`) + `ltkqchaphanh`) + `lttgngoaikhoa`) + `ltdangnn`) + `ltbieuduong`) + `ltgiupdo`) + `lttgdoanhoi`)) VIRTUAL,
  `gvythuc` int DEFAULT (`ythuc`),
  `gvclbhoc` int DEFAULT (`clbhoc`),
  `gvquyche` int DEFAULT (`quyche`),
  `gvvuotkho` int DEFAULT (`vuotkho`),
  `gvhoctap` int DEFAULT (`hoctap`),
  `gvtsvgioi` int DEFAULT (`tsvgioi`),
  `gvkqchaphanh` int DEFAULT (`kqchaphanh`),
  `gvtgngoaikhoa` int DEFAULT (`tgngoaikhoa`),
  `gvdangnn` int DEFAULT (`dangnn`),
  `gvbieuduong` int DEFAULT (`bieuduong`),
  `gvgiupdo` int DEFAULT (`giupdo`),
  `gvtgdoanhoi` int DEFAULT (`tgdoanhoi`),
  `gvtongdiem` int GENERATED ALWAYS AS ((((((((((((`gvythuc` + `gvclbhoc`) + `gvquyche`) + `gvvuotkho`) + `gvhoctap`) + `gvtsvgioi`) + `gvkqchaphanh`) + `gvtgngoaikhoa`) + `gvdangnn`) + `gvbieuduong`) + `gvgiupdo`) + `gvtgdoanhoi`)) VIRTUAL,
  `tthai` varchar(45) NOT NULL,
  PRIMARY KEY (`msv`),
  UNIQUE KEY `msv_UNIQUE` (`msv`),
  CONSTRAINT `drlsv` FOREIGN KEY (`msv`) REFERENCES `sinhvien` (`msv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drl`
--

LOCK TABLES `drl` WRITE;
/*!40000 ALTER TABLE `drl` DISABLE KEYS */;
INSERT INTO `drl` (`msv`, `ythuc`, `clbhoc`, `quyche`, `vuotkho`, `hoctap`, `tsvgioi`, `kqchaphanh`, `tgngoaikhoa`, `dangnn`, `bieuduong`, `giupdo`, `tgdoanhoi`, `ltythuc`, `ltclbhoc`, `ltquyche`, `ltvuotkho`, `lthoctap`, `lttsvgioi`, `ltkqchaphanh`, `lttgngoaikhoa`, `ltdangnn`, `ltbieuduong`, `ltgiupdo`, `lttgdoanhoi`, `gvythuc`, `gvclbhoc`, `gvquyche`, `gvvuotkho`, `gvhoctap`, `gvtsvgioi`, `gvkqchaphanh`, `gvtgngoaikhoa`, `gvdangnn`, `gvbieuduong`, `gvgiupdo`, `gvtgdoanhoi`, `tthai`) VALUES ('640001',4,2,2,2,8,2,25,20,15,5,5,10,4,2,2,2,8,2,25,20,15,5,5,10,4,2,2,2,8,2,25,20,15,5,5,10,'Lớp trưởng đã đánh giá'),('640002',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640003',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640004',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640005',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640006',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640007',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640008',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640009',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640010',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640011',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640012',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640013',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640014',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640015',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640016',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640017',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640018',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá'),('640019',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'Chưa đánh giá');
/*!40000 ALTER TABLE `drl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-10 21:16:37
